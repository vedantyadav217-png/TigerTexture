
const tigerBadge = document.createElement("div");

tigerBadge.style.cssText = `
  position: fixed;
  top: 15px;
  right: 15px;
  z-index: 999999;
  padding: 10px 14px;
  background: #151426;
  color: #c4b5fd;
  border: 1px solid #9b7bff;
  border-radius: 10px;
  font-family: Arial, sans-serif;
  font-size: 12px;
  font-weight: bold;
  box-shadow: 0 0 15px #6545b855;
`;

document.body.appendChild(tigerBadge);

function updateTigerBadge(texture) {
  tigerBadge.textContent = texture
    ? "🐯 TIGERTEXTURE • " + texture
    : "🐯 TIGERTEXTURE • No texture selected";
}

// Load saved selection
chrome.storage.local.get(["selectedTexture"], (result) => {
  updateTigerBadge(result.selectedTexture || null);
});

// Detect selection changes
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.selectedTexture) {
    updateTigerBadge(changes.selectedTexture.newValue || null);
  }
});
