
const textures = [
  { name: "Nightmare", icon: "🌙", image: "nightmare.png", redirects: 139 },
  { name: "Realistic", icon: "🌿", image: "realistic.png", redirects: 147 },
  { name: "Indian Theme", icon: "🇮🇳", image: "indian theme.png", redirects: 198 },
  { name: "Frostbite", icon: "❄️", image: "frostbite.png", redirects: 139 },
  { name: "Dunestorm", icon: "🏜️", image: "dunestorm.png", redirects: 147  },
  { name: "Volcanic", icon: "🌋", image: "volcanic.png", redirects: 147  },
  { name: "Oceanic", icon: "🌊", image: "oceanic.png", redirects: 139  },
  { name: "Haunted", icon: "👻", image: "haunted.png", redirects: 147  }
];

const activeArea = document.getElementById("activeTexture");
const textureList = document.getElementById("textureList");
const status = document.getElementById("status");

let activeTexture = null;
let loadingTexture = null;
let loadedTexture = null;

function renderTextures() {
  activeArea.innerHTML = "";
  textureList.innerHTML = "";

  if (activeTexture) {
    const selected = textures.find(t => t.name === activeTexture);
    const icon = selected ? selected.icon : "🎨";

    const activeCard = document.createElement("div");
    activeCard.className = "texture-card active-card";
    activeCard.innerHTML = `
      <div class="texture-name">✓ ${icon} ${activeTexture}</div>
      <div class="texture-info">Currently selected</div>
    `;
    activeArea.appendChild(activeCard);
  } else {
    activeArea.innerHTML = "<p>No active texture selected</p>";
  }

  const searchText = document.getElementById("textureSearch").value.toLowerCase();

const filteredTextures = textures.filter(texture =>
  texture.name.toLowerCase().includes(searchText)
);
document.getElementById("textureCount").textContent =
  "Showing " + filteredTextures.length + " textures";
if (filteredTextures.length === 0) {
  textureList.innerHTML =
    '<p style="text-align:center;color:#8b7ca8;font-size:11px;">No textures found 🔍</p>';
}

filteredTextures.forEach((texture) => {
    const card = document.createElement("div");
    card.className = "texture-card";

    if (texture.name === activeTexture) {
      card.classList.add("active-card");
    }

    const name = document.createElement("div");
    name.className = "texture-name";
    name.textContent =
  (texture.name === activeTexture ? "🟢 ✓ 🎨 " : "🎨 ") +
  texture.name;

    const info = document.createElement("div");
    info.className = "texture-info";
    info.textContent = texture.name === activeTexture
  ? "Currently selected"
  : (texture.redirects || 0) + " Redirects";
    const loading = document.createElement("div");
    loading.className = "texture-loading";

    if (texture.name === loadingTexture) {
      loading.classList.add("show");
      loading.innerHTML = `
        <div class="loading-spinner"></div>
        <span>Saving selection...</span>
      `;
    } else if (texture.name === loadedTexture) {
      loading.classList.add("show");
      loading.innerHTML = `
        <span class="texture-loaded">✓ Selected successfully</span>
      `;
    }

const description = document.createElement("div");
description.className = "texture-description";
description.textContent = texture.description;

card.appendChild(description);
    card.appendChild(name);
    card.appendChild(info);
    card.appendChild(loading);

    card.addEventListener("click", () => {
      if (loadingTexture) return;

      loadingTexture = texture.name;
      loadedTexture = null;

      status.textContent = "Loading " + texture.name + "...";
      renderTextures();

      chrome.storage.local.set(
        { selectedTexture: texture.name },
        () => {
          if (chrome.runtime.lastError) {
            loadingTexture = null;
            status.textContent = "Could not save texture.";
            renderTextures();
            return;
          }

          activeTexture = texture.name;
          loadingTexture = null;
          loadedTexture = texture.name;

          status.textContent = texture.name + " selected!";
          renderTextures();
        }
      );
    });

    textureList.appendChild(card);
  });
}

chrome.storage.local.get(["selectedTexture"], (result) => {
  activeTexture = result.selectedTexture || null;
  renderTextures();
});
document.getElementById("resetTexture").addEventListener("click", () => {
  chrome.storage.local.remove("selectedTexture", () => {
    document.getElementById("textureSearch").value = "";
    activeTexture = null;
    loadingTexture = null;
    loadedTexture = null;

    status.textContent = "Texture selection reset!";
    renderTextures();
  });
});
document.getElementById("textureSearch").addEventListener("input", () => {
  renderTextures();
});