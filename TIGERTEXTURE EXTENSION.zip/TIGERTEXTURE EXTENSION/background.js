
const textureFiles = [
  "tree_1_bright_green.png",
  "background_brown.png",
  "arena_tile_fill_breakable.png",
  "house_9.png",
  "castle_bg.png"
  // We'll add the remaining filenames next.
];

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

async function applyNightmareRules() {
  const existingRules =
    await chrome.declarativeNetRequest.getDynamicRules();

  const newRules = textureFiles.map((gameFile, index) => ({
    id: index + 1,
    priority: 1,
    action: {
      type: "redirect",
      redirect: {
        extensionPath: `/textures/Nightmare/${gameFile}`
      }
    },
    condition: {
      regexFilter:
        `^https?://.*evoworld\\.io/.*/${escapeRegex(gameFile)}(\\?.*)?$`,
      resourceTypes: ["image", "xmlhttprequest"],
      excludedInitiatorDomains: [chrome.runtime.id]
    }
  }));

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: existingRules.map(rule => rule.id),
    addRules: newRules
  });
}

chrome.runtime.onInstalled.addListener(() => {
  applyNightmareRules().catch(console.error);
});

chrome.runtime.onStartup.addListener(() => {
  applyNightmareRules().catch(console.error);
});
